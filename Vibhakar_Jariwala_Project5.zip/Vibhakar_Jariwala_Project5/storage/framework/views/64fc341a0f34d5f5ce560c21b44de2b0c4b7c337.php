<form action="login" method="post">
<input type="text" name="user">
<input type="password" name="password">
<?php echo csrf_field(); ?>
<input type="submit" name="login" value="login">
</form><?php /**PATH C:\Users\Prayag\Desktop\project5\resources\views/login.blade.php ENDPATH**/ ?>