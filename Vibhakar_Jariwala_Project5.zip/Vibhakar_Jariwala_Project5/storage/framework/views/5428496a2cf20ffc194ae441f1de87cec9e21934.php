<h1>Profile</h1>

<h3><?php echo e(session('data')); ?></h3>


<?php /**PATH C:\Users\Prayag\Desktop\project5\resources\views/profile.blade.php ENDPATH**/ ?>